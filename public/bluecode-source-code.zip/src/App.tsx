import React, { useState } from 'react';
import { ThemeProvider, useTheme } from './context/ThemeContext';
import { BackgroundDots } from './components/BackgroundDots';
import { Navbar } from './components/Navbar';
import { HeroSection } from './components/HeroSection';
import { FeaturesSection } from './components/FeaturesSection';
import { HowItWorksSection } from './components/HowItWorksSection';
import { StudioSection } from './components/StudioSection';
import { MetricsSection } from './components/MetricsSection';
import { IntegrationsSection } from './components/IntegrationsSection';
import { SecuritySection } from './components/SecuritySection';
import { DeliverablesSection } from './components/DeliverablesSection';
import { PricingSection } from './components/PricingSection';
import { CtaSection } from './components/CtaSection';
import { FooterSection } from './components/FooterSection';
import { BookingModal } from './components/BookingModal';
import { FloatingWhatsApp } from './components/FloatingWhatsApp';

function AppContent() {
  const { isDark } = useTheme();
  const [bookingModalOpen, setBookingModalOpen] = useState(false);
  const [selectedPlanForBooking, setSelectedPlanForBooking] = useState('Enterprise Custom');

  const handleOpenBooking = (planOrService?: string) => {
    if (planOrService) {
      setSelectedPlanForBooking(planOrService);
    } else {
      setSelectedPlanForBooking('Enterprise Custom');
    }
    setBookingModalOpen(true);
  };

  return (
    <div className="min-h-screen bg-[#FBFBFA] dark:bg-[#060913] text-[#0A0D14] dark:text-slate-100 flex flex-col font-sans selection:bg-[#0052FF] selection:text-white transition-colors duration-300 relative">
      {/* Background Dots Masked Vertical with blinking blue cursor hover animation */}
      <BackgroundDots isDark={isDark} />

      {/* Navigation (with Dark/Light Mode switch, no cPanel button) */}
      <Navbar onOpenBooking={() => handleOpenBooking()} />

      {/* Main Content Sections */}
      <main className="flex-1 relative z-10">
        {/* Hero Section with 3D ASCII Sphere and Live Marquee */}
        <HeroSection onOpenBooking={() => handleOpenBooking()} />

        {/* 01-05 Services / Capabilities */}
        <FeaturesSection onOpenBooking={handleOpenBooking} />

        {/* 3-Step Process (Discover, Design, Launch) with Live Markdown Code Simulator */}
        <HowItWorksSection />

        {/* Our Studio: Rooted in Kathmandu, Nepal & Industries We Serve */}
        <StudioSection />

        {/* Results you can measure & Kathmandu, Nepal live clock */}
        <MetricsSection />

        {/* Tools & Platforms Section ("Powered by the best creative tools") */}
        <IntegrationsSection />

        {/* Principles & Standards of Craft */}
        <SecuritySection />

        {/* Our Work: Case Study Deliverables Interactive Code Terminal */}
        <DeliverablesSection />

        {/* Packages & Pricing: Essentials NPR 2,500, Growth NPR 3,500, 20% annual discount, Enterprise Custom */}
        <PricingSection onOpenBooking={handleOpenBooking} />

        {/* 3D ASCII Tetrahedron Interactive CTA Section matching original light theme */}
        <CtaSection onOpenBooking={() => handleOpenBooking('General Consultation')} />
      </main>

      {/* Footer with Blue Code branding, Kathmandu, Nepal, and ASCII Wave matrix */}
      <FooterSection />

      {/* Interactive Consultation & WhatsApp Booking Modal */}
      <BookingModal
        isOpen={bookingModalOpen}
        onClose={() => setBookingModalOpen(false)}
        selectedPlan={selectedPlanForBooking}
      />

      {/* Floating 24/7 WhatsApp Chat Support Widget */}
      <FloatingWhatsApp onOpenBooking={() => handleOpenBooking()} />
    </div>
  );
}

export default function App() {
  return (
    <ThemeProvider>
      <AppContent />
    </ThemeProvider>
  );
}
