import React, { useEffect, useRef } from 'react';

interface BackgroundDotsProps {
  isDark?: boolean;
}

export const BackgroundDots: React.FC<BackgroundDotsProps> = ({ isDark = false }) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const mouseRef = useRef<{ x: number; y: number; active: boolean }>({ x: -1000, y: -1000, active: false });
  const animFrameId = useRef<number>(0);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let width = (canvas.width = window.innerWidth);
    let height = (canvas.height = window.innerHeight);

    const handleResize = () => {
      if (!canvas) return;
      const dpr = Math.min(window.devicePixelRatio || 1, 2);
      width = window.innerWidth;
      height = window.innerHeight;
      canvas.width = width * dpr;
      canvas.height = height * dpr;
      ctx.scale(dpr, dpr);
    };

    handleResize();
    window.addEventListener('resize', handleResize);

    const handleMouseMove = (e: MouseEvent) => {
      mouseRef.current = {
        x: e.clientX,
        y: e.clientY,
        active: true,
      };
    };

    const handleMouseLeave = () => {
      mouseRef.current.active = false;
    };

    window.addEventListener('mousemove', handleMouseMove, { passive: true });
    document.addEventListener('mouseleave', handleMouseLeave);

    // Dot grid configuration
    const spacing = 28; // Distance between dots
    const hoverRadius = 140; // Proximity to trigger blinking blue effect

    // Store transient energy/decay values for interactive hover trails
    // Map key: "col_row" -> energy: number (0 to 1), seed: number
    const dotEnergyMap = new Map<string, { energy: number; seed: number }>();

    let time = 0;

    const render = () => {
      ctx.clearRect(0, 0, width, height);

      const cols = Math.ceil(width / spacing) + 1;
      const rows = Math.ceil(height / spacing) + 1;
      const mx = mouseRef.current.x;
      const my = mouseRef.current.y;
      const mouseActive = mouseRef.current.active;

      time += 0.04;

      for (let r = 0; r < rows; r++) {
        const y = r * spacing;

        // Vertical mask: Fade out near extreme top (0 - 15%) and bottom (85% - 100%)
        const normY = y / height;
        let verticalMask = 1;
        if (normY < 0.15) {
          verticalMask = Math.max(0, normY / 0.15);
        } else if (normY > 0.85) {
          verticalMask = Math.max(0, (1 - normY) / 0.15);
        }

        // Apply smooth sine easing for the vertical mask
        const maskAlpha = Math.sin(verticalMask * Math.PI * 0.5);
        if (maskAlpha <= 0.01) continue;

        for (let c = 0; c < cols; c++) {
          const x = c * spacing;
          const key = `${c}_${r}`;

          let dotData = dotEnergyMap.get(key);
          if (!dotData) {
            dotData = { energy: 0, seed: (c * 17 + r * 31) % 100 };
            dotEnergyMap.set(key, dotData);
          }

          // Check proximity to cursor
          let targetEnergy = 0;
          if (mouseActive) {
            const dist = Math.hypot(x - mx, y - my);
            if (dist < hoverRadius) {
              targetEnergy = 1 - dist / hoverRadius;
            }
          }

          // Smoothly ramp up on hover, decay gracefully when cursor leaves
          if (targetEnergy > dotData.energy) {
            dotData.energy = dotData.energy + (targetEnergy - dotData.energy) * 0.4;
          } else {
            dotData.energy *= 0.94; // Decay trail
          }

          const hasEnergy = dotData.energy > 0.02;

          if (hasEnergy) {
            // Blinking Blue where cursor hovered
            // Fast pulse frequency: 10 + seed modifier
            const blinkPulse = Math.sin(time * 10 + dotData.seed) * 0.5 + 0.5;
            const blinkFactor = 0.5 + 0.5 * blinkPulse;
            const activeAlpha = dotData.energy * maskAlpha * blinkFactor;

            // Draw glowing halo around active dots
            const glowRadius = 2.5 + dotData.energy * 2.5;
            ctx.beginPath();
            ctx.arc(x, y, glowRadius, 0, Math.PI * 2);

            if (isDark) {
              // Glowing electric cyan/blue in dark mode
              ctx.fillStyle = `rgba(0, 210, 255, ${Math.min(activeAlpha * 0.9, 0.95)})`;
              ctx.shadowColor = '#00D2FF';
              ctx.shadowBlur = 8 * dotData.energy;
            } else {
              // High-vibrancy royal electric blue in light mode
              ctx.fillStyle = `rgba(0, 82, 255, ${Math.min(activeAlpha * 0.95, 0.95)})`;
              ctx.shadowColor = '#0052FF';
              ctx.shadowBlur = 6 * dotData.energy;
            }
            ctx.fill();

            // Draw bright core dot
            ctx.beginPath();
            ctx.arc(x, y, 1.8 + dotData.energy * 0.8, 0, Math.PI * 2);
            ctx.fillStyle = isDark ? '#FFFFFF' : '#0038D1';
            ctx.shadowBlur = 0;
            ctx.fill();
          } else {
            // Idle background dot (clean, quiet, masked vertically)
            // Subtle ambient twinkle for random dots (1 in 40)
            const isAmbient = dotData.seed % 38 === 0;
            let dotAlpha = (isDark ? 0.18 : 0.22) * maskAlpha;

            if (isAmbient) {
              const ambientBlink = Math.sin(time * 3 + dotData.seed) * 0.5 + 0.5;
              if (ambientBlink > 0.7) {
                // Occasional subtle blue twinkle
                dotAlpha += (ambientBlink - 0.7) * 0.4 * maskAlpha;
                ctx.fillStyle = isDark
                  ? `rgba(0, 180, 255, ${dotAlpha})`
                  : `rgba(0, 82, 255, ${dotAlpha})`;
              } else {
                ctx.fillStyle = isDark
                  ? `rgba(255, 255, 255, ${dotAlpha})`
                  : `rgba(100, 116, 139, ${dotAlpha})`;
              }
            } else {
              ctx.fillStyle = isDark
                ? `rgba(255, 255, 255, ${dotAlpha})`
                : `rgba(100, 116, 139, ${dotAlpha})`;
            }

            ctx.shadowBlur = 0;
            ctx.beginPath();
            ctx.arc(x, y, 1.1, 0, Math.PI * 2);
            ctx.fill();
          }
        }
      }

      animFrameId.current = requestAnimationFrame(render);
    };

    render();

    return () => {
      window.removeEventListener('resize', handleResize);
      window.removeEventListener('mousemove', handleMouseMove);
      document.removeEventListener('mouseleave', handleMouseLeave);
      cancelAnimationFrame(animFrameId.current);
    };
  }, [isDark]);

  return (
    <div
      className="fixed inset-0 pointer-events-none z-0 overflow-hidden"
      style={{
        maskImage: 'linear-gradient(to bottom, transparent 0%, rgba(0,0,0,0.8) 10%, rgba(0,0,0,1) 50%, rgba(0,0,0,0.8) 90%, transparent 100%)',
        WebkitMaskImage: 'linear-gradient(to bottom, transparent 0%, rgba(0,0,0,0.8) 10%, rgba(0,0,0,1) 50%, rgba(0,0,0,0.8) 90%, transparent 100%)',
      }}
      aria-hidden="true"
    >
      <canvas ref={canvasRef} className="w-full h-full block" />
    </div>
  );
};
