import React from 'react';

export const IntegrationsSection: React.FC = () => {
  const toolsTop = [
    { name: 'Adobe Premiere Pro', category: 'Adobe Suite' },
    { name: 'Figma', category: 'UI/UX Design' },
    { name: 'Meta Ads', category: 'Social Advertising' },
    { name: 'Google Ads', category: 'Search & Display' },
    { name: 'WordPress', category: 'Web Platform' },
    { name: 'Shopify', category: 'E-commerce' },
    { name: 'Mailchimp', category: 'Email Marketing' },
    { name: 'Hootsuite', category: 'Social Management' },
  ];

  const toolsBottom = [
    { name: 'Google Analytics', category: 'Performance Tracking' },
    { name: 'Hootsuite', category: 'Social Management' },
    { name: 'Mailchimp', category: 'Email Marketing' },
    { name: 'Shopify', category: 'E-commerce' },
    { name: 'WordPress', category: 'Web Platform' },
    { name: 'Google Ads', category: 'Search & Display' },
    { name: 'Meta Ads', category: 'Social Advertising' },
    { name: 'Figma', category: 'UI/UX Design' },
  ];

  return (
    <section className="relative py-28 lg:py-36 bg-[#FBFBFA] dark:bg-[#060913] border-t border-slate-200/80 dark:border-slate-800 overflow-hidden transition-colors">
      {/* Centered Section Header matching 100% original design */}
      <div className="max-w-3xl mx-auto px-6 text-center mb-16 lg:mb-20 relative z-10">
        <div className="flex items-center justify-center gap-4 text-xs font-medium tracking-widest text-slate-500 dark:text-cyan-400 uppercase mb-6">
          <span className="w-8 h-px bg-slate-300 dark:bg-slate-700" />
          <span>Tools & Platforms</span>
          <span className="w-8 h-px bg-slate-300 dark:bg-slate-700" />
        </div>

        <h2 className="text-4xl sm:text-5xl lg:text-6xl font-bold tracking-tight text-[#0A0D14] dark:text-white mb-6 leading-tight">
          Powered by the best <br />
          creative tools.
        </h2>

        <p className="text-lg lg:text-xl text-slate-600 dark:text-slate-300 leading-relaxed max-w-2xl mx-auto">
          We leverage industry-leading platforms to deliver exceptional results for every client.
        </p>
      </div>

      {/* Row 1: Forward Marquee */}
      <div className="w-full mb-6 overflow-hidden relative z-10">
        <div className="marquee">
          {[...toolsTop, ...toolsTop, ...toolsTop].map((tool, idx) => (
            <div
              key={`top-${tool.name}-${idx}`}
              className="shrink-0 mx-3 px-8 py-6 bg-white dark:bg-[#0C1222] border border-slate-200/90 dark:border-slate-800 hover:border-[#002068]/30 dark:hover:border-cyan-400/40 hover:bg-[#002068]/[0.02] dark:hover:bg-cyan-500/[0.04] transition-all duration-300 group select-none min-w-[220px]"
            >
              <div className="text-lg font-medium text-[#0A0D14] dark:text-white group-hover:translate-x-1 group-hover:text-[#0052FF] dark:group-hover:text-cyan-400 transition-all duration-300">
                {tool.name}
              </div>
              <div className="text-sm text-slate-500 dark:text-slate-400 mt-1">
                {tool.category}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Row 2: Reverse Marquee */}
      <div className="w-full overflow-hidden relative z-10">
        <div className="marquee-reverse">
          {[...toolsBottom, ...toolsBottom, ...toolsBottom].map((tool, idx) => (
            <div
              key={`bottom-${tool.name}-${idx}`}
              className="shrink-0 mx-3 px-8 py-6 bg-white dark:bg-[#0C1222] border border-slate-200/90 dark:border-slate-800 hover:border-[#002068]/30 dark:hover:border-cyan-400/40 hover:bg-[#002068]/[0.02] dark:hover:bg-cyan-500/[0.04] transition-all duration-300 group select-none min-w-[220px]"
            >
              <div className="text-lg font-medium text-[#0A0D14] dark:text-white group-hover:translate-x-1 group-hover:text-[#0052FF] dark:group-hover:text-cyan-400 transition-all duration-300">
                {tool.name}
              </div>
              <div className="text-sm text-slate-500 dark:text-slate-400 mt-1">
                {tool.category}
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
