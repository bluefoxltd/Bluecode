import React, { useEffect, useRef, useState } from 'react';
import { ArrowRight } from 'lucide-react';
import { useTheme } from '../context/ThemeContext';

interface HeroSectionProps {
  onOpenBooking: () => void;
}

export const HeroSection: React.FC<HeroSectionProps> = ({ onOpenBooking }) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const animFrameId = useRef<number>(0);
  const { isDark } = useTheme();

  // Changeable text content specified by the user:
  // - Inspire
  // - Stand Out
  // - Resonate
  // - Convert
  const changeableWords = ['Inspire', 'Stand Out', 'Resonate', 'Convert'];
  const [wordIndex, setWordIndex] = useState(2); // Start on 'Resonate'
  const [fadeState, setFadeState] = useState<'in' | 'out'>('in');

  // Changeable word rotation timer
  useEffect(() => {
    const interval = setInterval(() => {
      setFadeState('out');
      setTimeout(() => {
        setWordIndex((prev) => (prev + 1) % changeableWords.length);
        setFadeState('in');
      }, 300);
    }, 2800);

    return () => clearInterval(interval);
  }, [changeableWords.length]);

  // 50% Smaller Animated Dots & Nodes Linked Globe Canvas (restricted to right half)
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // ASCII characters matching curradigital.com globe
    const chars = '│─┤├┴┬╭╮╰╯░▒▓█▀▄▌▐';
    let step = 0;

    const resize = () => {
      if (!canvas) return;
      const dpr = Math.min(window.devicePixelRatio || 1, 2);
      const rect = canvas.getBoundingClientRect();
      canvas.width = rect.width * dpr;
      canvas.height = rect.height * dpr;
      ctx.scale(dpr, dpr);
    };

    resize();
    window.addEventListener('resize', resize);

    // Geometry definition for 50% scaled dots & nodes globe
    const rings = 14;
    const nodesPerRing = 28;

    const render = () => {
      const rect = canvas.getBoundingClientRect();
      ctx.clearRect(0, 0, rect.width, rect.height);

      const cx = rect.width / 2;
      const cy = rect.height / 2;
      // Proportional radius to fit compactly inside right half
      const radius = 0.44 * Math.min(rect.width, rect.height);

      step += 0.008;

      interface GlobeNode {
        x2d: number;
        y2d: number;
        z: number;
        char: string;
        ring: number;
        idx: number;
        isOrbital?: boolean;
      }

      const nodes: GlobeNode[] = [];
      const ringNodes: GlobeNode[][] = [];

      // 1. Generate Latitude & Longitude Sphere Nodes
      for (let r = 0; r < rings; r++) {
        ringNodes[r] = [];
        const phi = (r / (rings - 1)) * Math.PI - Math.PI / 2;
        const cosPhi = Math.cos(phi);
        const sinPhi = Math.sin(phi);

        for (let j = 0; j < nodesPerRing; j++) {
          const theta = (j / nodesPerRing) * Math.PI * 2 + step;
          const x0 = Math.cos(theta) * cosPhi;
          const y0 = sinPhi;
          const z0 = Math.sin(theta) * cosPhi;

          // 3D rotation with natural tilt
          const angleX = 0.42;
          const y1 = y0 * Math.cos(angleX) - z0 * Math.sin(angleX);
          const z1 = y0 * Math.sin(angleX) + z0 * Math.cos(angleX);

          const angleY = step * 0.6;
          const x2 = x0 * Math.cos(angleY) + z1 * Math.sin(angleY);
          const z2 = -x0 * Math.sin(angleY) + z1 * Math.cos(angleY);

          const charIdx = (r * 7 + j * 13) % chars.length;

          const node: GlobeNode = {
            x2d: cx + x2 * radius,
            y2d: cy + y1 * radius,
            z: z2,
            char: chars[charIdx],
            ring: r,
            idx: j,
          };

          nodes.push(node);
          ringNodes[r].push(node);
        }
      }

      // 2. Generate Tilted Orbital Rings (Nodes & Linking Dots)
      const orbitalNodes: GlobeNode[] = [];
      const orbitalCount = 36;
      const orbitTilt = -0.52;

      for (let k = 0; k < orbitalCount; k++) {
        const theta = (k / orbitalCount) * Math.PI * 2 + step * 1.4;
        const rOrbit = radius * 1.14;
        const x0 = Math.cos(theta) * rOrbit;
        const y0 = Math.sin(theta) * Math.sin(orbitTilt) * rOrbit;
        const z0 = Math.sin(theta) * Math.cos(orbitTilt) * rOrbit;

        const angleX = 0.35;
        const y1 = y0 * Math.cos(angleX) - z0 * Math.sin(angleX);
        const z1 = y0 * Math.sin(angleX) + z0 * Math.cos(angleX);

        const node: GlobeNode = {
          x2d: cx + x0,
          y2d: cy + y1,
          z: z1,
          char: k % 3 === 0 ? '○' : '·',
          ring: -1,
          idx: k,
          isOrbital: true,
        };
        orbitalNodes.push(node);
      }

      // 3. Draw Linked Lines between neighboring nodes
      ctx.lineWidth = 0.8;

      // Draw latitude links
      for (let r = 0; r < rings; r++) {
        const ring = ringNodes[r];
        for (let j = 0; j < nodesPerRing; j++) {
          const n1 = ring[j];
          const n2 = ring[(j + 1) % nodesPerRing];

          if (n1.z > -0.3 || n2.z > -0.3) {
            const avgZ = (n1.z + n2.z) / 2;
            const alpha = Math.max(0.04, Math.min(0.28, 0.08 + (avgZ + 1) * 0.14));

            ctx.strokeStyle = isDark
              ? `rgba(56, 189, 248, ${alpha * 1.1})`
              : `rgba(0, 32, 104, ${alpha * 0.8})`;

            ctx.beginPath();
            ctx.moveTo(n1.x2d, n1.y2d);
            ctx.lineTo(n2.x2d, n2.y2d);
            ctx.stroke();
          }
        }
      }

      // Draw meridian links
      for (let r = 0; r < rings - 1; r += 2) {
        for (let j = 0; j < nodesPerRing; j += 3) {
          const n1 = ringNodes[r][j];
          const n2 = ringNodes[r + 1][j];

          if (n1.z > -0.2 || n2.z > -0.2) {
            const avgZ = (n1.z + n2.z) / 2;
            const alpha = Math.max(0.03, Math.min(0.22, 0.06 + (avgZ + 1) * 0.12));

            ctx.strokeStyle = isDark
              ? `rgba(56, 189, 248, ${alpha})`
              : `rgba(0, 32, 104, ${alpha * 0.7})`;

            ctx.beginPath();
            ctx.moveTo(n1.x2d, n1.y2d);
            ctx.lineTo(n2.x2d, n2.y2d);
            ctx.stroke();
          }
        }
      }

      // Draw orbital ring links
      for (let k = 0; k < orbitalCount; k++) {
        const o1 = orbitalNodes[k];
        const o2 = orbitalNodes[(k + 1) % orbitalCount];
        const avgZ = (o1.z + o2.z) / 2;
        const alpha = Math.max(0.04, Math.min(0.25, 0.08 + (avgZ + 1) * 0.12));

        ctx.strokeStyle = isDark
          ? `rgba(0, 210, 255, ${alpha})`
          : `rgba(0, 82, 255, ${alpha * 0.75})`;

        ctx.beginPath();
        ctx.moveTo(o1.x2d, o1.y2d);
        ctx.lineTo(o2.x2d, o2.y2d);
        ctx.stroke();
      }

      // 4. Sort and Draw Nodes (Dots & ASCII Glyphs)
      const allDrawableNodes = [...nodes, ...orbitalNodes].sort((a, b) => a.z - b.z);

      ctx.font = '11px monospace';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';

      allDrawableNodes.forEach((node) => {
        const depth = (node.z + 1.2) / 2.4;
        const alpha = Math.max(0.12, Math.min(0.92, 0.15 + depth * 0.75));

        if (node.isOrbital) {
          ctx.beginPath();
          ctx.arc(node.x2d, node.y2d, 1.6, 0, Math.PI * 2);
          ctx.fillStyle = isDark
            ? `rgba(56, 189, 248, ${alpha})`
            : `rgba(0, 82, 255, ${alpha})`;
          ctx.fill();
        } else {
          const isDotNode = node.idx % 2 === 0;

          if (isDotNode) {
            ctx.beginPath();
            const dotSize = 1.1 + depth * 1.4;
            ctx.arc(node.x2d, node.y2d, dotSize, 0, Math.PI * 2);
            ctx.fillStyle = isDark
              ? `rgba(56, 189, 248, ${alpha})`
              : `rgba(0, 32, 104, ${alpha})`;
            ctx.fill();
          } else {
            ctx.fillStyle = isDark
              ? `rgba(125, 211, 252, ${alpha * 0.9})`
              : `rgba(0, 32, 104, ${alpha * 0.85})`;
            ctx.fillText(node.char, node.x2d, node.y2d);
          }
        }
      });

      animFrameId.current = requestAnimationFrame(render);
    };

    render();

    return () => {
      window.removeEventListener('resize', resize);
      cancelAnimationFrame(animFrameId.current);
    };
  }, [isDark]);

  const marqueeStats = [
    { value: '98%', label: 'client retention', context: 'TRUSTED PARTNER' },
    { value: '3x', label: 'average engagement lift', context: 'SOCIAL MEDIA' },
    { value: '12+', label: 'industries served', context: 'NEPAL & BEYOND' },
    { value: '10+', label: 'brands transformed', context: 'BLUE CODE' },
  ];

  const handleStartProject = () => {
    const currentWord = changeableWords[wordIndex];
    const text = encodeURIComponent(
      `Hello Blue Code! I would like to start a project to build a brand that ${currentWord.toLowerCase()}.`
    );
    window.open(`https://wa.me/9779715971505?text=${text}`, '_blank', 'noopener,noreferrer');
  };

  return (
    <section className="relative min-h-[90vh] lg:min-h-screen pt-32 lg:pt-36 pb-16 overflow-hidden flex flex-col justify-between">
      {/* Background radial aura constrained to the right side */}
      <div className="absolute top-1/3 right-10 -z-10 w-[420px] h-[420px] bg-gradient-to-b from-[#0052FF]/10 dark:from-[#0052FF]/20 via-cyan-400/5 to-transparent rounded-full blur-3xl pointer-events-none" />

      {/* Main Content Split: Left half text content, Right half 50% smaller globe */}
      <div className="max-w-[1400px] mx-auto px-6 lg:px-12 w-full relative z-10 my-auto">
        <div className="grid lg:grid-cols-12 gap-8 lg:gap-12 items-center">
          
          {/* Left Column (Covers Left Half ~60%): Headline, Subtitle, Buttons */}
          <div className="lg:col-span-7 space-y-6 lg:space-y-8">
            <h1 className="text-5xl sm:text-6xl md:text-7xl lg:text-[5.5rem] xl:text-[6.2rem] font-bold tracking-tight text-[#0A0D14] dark:text-white leading-[0.98] text-balance">
              <span>Building Brands</span>
              <br />
              <span className="flex flex-wrap items-baseline mt-2">
                <span>that</span>
                {/* Changeable animated text with navy blue color & underline */}
                <span className="relative inline-block ml-3 sm:ml-4 text-[#002068] dark:text-cyan-400">
                  <span
                    className={`inline-block transition-all duration-300 transform ${
                      fadeState === 'in'
                        ? 'opacity-100 translate-y-0'
                        : 'opacity-0 -translate-y-3'
                    }`}
                  >
                    {changeableWords[wordIndex]}
                  </span>
                  {/* Sleek Navy Blue underline below changeable contents */}
                  <span className="block w-full h-[4px] sm:h-[5px] lg:h-[6px] bg-[#002068] dark:bg-cyan-400 rounded-full mt-1 transition-all duration-300" />
                </span>
              </span>
            </h1>

            {/* Subtext description */}
            <p className="text-base sm:text-lg lg:text-xl text-slate-600 dark:text-slate-300 max-w-xl leading-relaxed pt-1">
              We craft distinctive brand identities and digital experiences that captivate audiences and drive measurable growth.
            </p>

            {/* Two CTA Buttons */}
            <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-4 pt-2">
              <button
                onClick={handleStartProject}
                className="group inline-flex items-center justify-center gap-2.5 px-8 h-14 rounded-full bg-[#002068] dark:bg-[#0052FF] hover:bg-[#0038D1] dark:hover:bg-[#0038D1] text-white text-base font-semibold shadow-lg shadow-blue-900/10 dark:shadow-blue-500/20 transition-all duration-300"
              >
                <span>Start a Project</span>
                <ArrowRight className="w-4 h-4 transition-transform group-hover:translate-x-1" />
              </button>

              <a
                href="#work"
                className="inline-flex items-center justify-center px-8 h-14 rounded-full border border-slate-300 dark:border-slate-700 bg-white/60 dark:bg-slate-900/60 hover:bg-white dark:hover:bg-slate-800 text-slate-800 dark:text-slate-200 text-base font-medium transition-all duration-300"
              >
                View Our Work
              </a>
            </div>
          </div>

          {/* Right Column (Covers Right Half ~40%): 50% Smaller Animated Globe */}
          <div className="lg:col-span-5 flex items-center justify-center lg:justify-end">
            <div className="w-[300px] h-[300px] sm:w-[380px] sm:h-[380px] lg:w-[450px] lg:h-[450px] xl:w-[500px] xl:h-[500px] relative pointer-events-none">
              <canvas
                ref={canvasRef}
                className="w-full h-full block opacity-95"
              />
            </div>
          </div>

        </div>
      </div>

      {/* Bottom Marquee Statistics Strip matching screenshot */}
      <div className="mt-14 lg:mt-16 border-y border-slate-200/80 dark:border-slate-800 bg-white/60 dark:bg-slate-900/60 backdrop-blur-xs py-5 overflow-hidden relative z-10">
        <div className="marquee">
          {[...marqueeStats, ...marqueeStats, ...marqueeStats].map((stat, idx) => (
            <div key={idx} className="flex items-baseline gap-4 mx-8 lg:mx-12 shrink-0">
              <span className="text-3xl lg:text-4xl font-bold tracking-tight text-[#002068] dark:text-white">
                {stat.value}
              </span>
              <span className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 font-medium">
                {stat.label}
                <span className="block text-[10px] font-semibold text-slate-400 dark:text-cyan-400/80 tracking-wider uppercase mt-0.5">
                  {stat.context}
                </span>
              </span>
              <span className="text-slate-300 dark:text-slate-700 ml-8 select-none">/</span>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
